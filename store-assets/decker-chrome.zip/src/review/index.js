import { r as reactExports, j as jsxRuntimeExports, s as statusUpdateIsCurrent, d as createRoot, R as React } from "../../chunks/model-BWRRjeyJ.js";
import { M as MessageType } from "../../chunks/types-Do_9m9s4.js";
function restoredTranscript(state) {
  if (state.edit?.baseRevision === state.transcriptRevision) {
    return { text: state.edit.text, edited: true };
  }
  return { text: state.transcript ?? "", edited: false };
}
const formatOptions = [
  { value: "doc", label: "Document", detail: "Structured notes and action items" },
  { value: "presentation", label: "Presentation", detail: "A Reveal.js slide deck" },
  { value: "prototype", label: "Prototype", detail: "An interactive HTML concept" },
  { value: "notes", label: "Discussion site", detail: "A scrollable HTML summary" }
];
function progressText(status, message) {
  if (message) return message;
  switch (status) {
    case "recording":
      return "Recording is still active. Stop it from the Decker popup.";
    case "processing":
      return "Finishing audio capture...";
    case "finalizing":
      return "Preparing the saved audio...";
    case "transcribing":
      return "Finishing the transcript...";
    case "extracting":
      return "Finding discussion topics...";
    case "researching":
      return "Adding context for selected topics...";
    case "generating":
      return "Building the artifact...";
    case "done":
      return "Artifact ready";
    case "reviewing":
      return "Review the transcript and choose what to create.";
    case "error":
      return "The session needs attention.";
    default:
      return "No recording is ready for review.";
  }
}
function researchLabel(research) {
  if (!research || research.status === "pending") return "Waiting";
  if (research.status === "researching") return "Adding context...";
  if (research.status === "done") return "Context ready";
  return "Context unavailable";
}
function Review() {
  const [state, setState] = reactExports.useState(null);
  const [transcript, setTranscript] = reactExports.useState("");
  const [canonicalTranscript, setCanonicalTranscript] = reactExports.useState("");
  const [editBaseRevision, setEditBaseRevision] = reactExports.useState(0);
  const [selectedPoints, setSelectedPoints] = reactExports.useState([]);
  const [customPrompt, setCustomPrompt] = reactExports.useState("");
  const [outputFormat, setOutputFormat] = reactExports.useState("doc");
  const [notice, setNotice] = reactExports.useState(null);
  const [conflict, setConflict] = reactExports.useState(false);
  const [hydrated, setHydrated] = reactExports.useState(false);
  const [saving, setSaving] = reactExports.useState(false);
  const headingRef = reactExports.useRef(null);
  const errorRef = reactExports.useRef(null);
  const sessionRef = reactExports.useRef({ id: "", generation: -1, revision: 0 });
  const dirtyRef = reactExports.useRef(false);
  const hydrate = reactExports.useCallback((next) => {
    const restored = restoredTranscript(next);
    sessionRef.current = { id: next.sessionId, generation: next.sessionGeneration, revision: next.transcriptRevision };
    dirtyRef.current = restored.edited;
    setState(next);
    setCanonicalTranscript(next.transcript ?? "");
    setTranscript(restored.text);
    setEditBaseRevision(next.transcriptRevision);
    setSelectedPoints(next.selectedPoints);
    setCustomPrompt(next.customPrompt);
    setOutputFormat(next.outputFormat);
    setConflict(false);
  }, []);
  reactExports.useEffect(() => {
    const onMessage = (message) => {
      if (message.type !== MessageType.STATUS_UPDATE) return;
      const update = message.payload;
      const current = sessionRef.current;
      if (!statusUpdateIsCurrent(current.id, current.generation, current.revision, update)) return;
      const nextGeneration = update.sessionGeneration ?? current.generation;
      const nextRevision = update.transcriptRevision ?? current.revision;
      const newSession = nextGeneration > current.generation || update.sessionId && update.sessionId !== current.id;
      if (newSession) {
        void chrome.runtime.sendMessage({ type: MessageType.GET_FULL_STATE }).then(hydrate);
        return;
      }
      if (nextRevision > current.revision && dirtyRef.current) setConflict(true);
      sessionRef.current = { id: update.sessionId ?? current.id, generation: nextGeneration, revision: nextRevision };
      setState((previous) => previous ? {
        ...previous,
        status: update.status,
        message: update.message,
        transcriptRevision: nextRevision,
        warnings: update.warnings ?? previous.warnings,
        transcript: update.transcript ?? previous.transcript,
        points: update.points ?? previous.points,
        selectedPoints: update.selectedPoints ?? previous.selectedPoints,
        topicResearch: update.topicResearch ?? previous.topicResearch,
        hasHtml: update.hasHtml ?? previous.hasHtml
      } : previous);
      if (update.transcript !== void 0) {
        setCanonicalTranscript(update.transcript);
        if (!dirtyRef.current) {
          setTranscript(update.transcript);
          setEditBaseRevision(nextRevision);
        }
      }
      if (update.selectedPoints) setSelectedPoints(update.selectedPoints);
    };
    chrome.runtime.onMessage.addListener(onMessage);
    chrome.runtime.sendMessage({ type: MessageType.GET_FULL_STATE }).then((response) => {
      if (!response || response.error) throw new Error(response?.error ?? "Decker could not restore the saved session.");
      hydrate(response);
      setHydrated(true);
      requestAnimationFrame(() => headingRef.current?.focus());
    }).catch((reason) => {
      setNotice({ kind: "error", text: reason instanceof Error ? reason.message : String(reason) });
      setHydrated(true);
    });
    return () => chrome.runtime.onMessage.removeListener(onMessage);
  }, [hydrate]);
  reactExports.useEffect(() => {
    if (!hydrated || !state || conflict) return;
    const timer = window.setTimeout(async () => {
      setSaving(true);
      const edited = transcript !== canonicalTranscript;
      const response = await chrome.runtime.sendMessage({
        type: MessageType.SAVE_REVIEW,
        payload: {
          sessionId: state.sessionId,
          selectedPoints,
          customPrompt,
          outputFormat,
          edit: edited ? { text: transcript, baseRevision: editBaseRevision } : null
        }
      }).catch((reason) => ({ error: reason instanceof Error ? reason.message : String(reason) }));
      setSaving(false);
      if (response?.error) {
        setNotice({ kind: "error", text: response.error });
        if (/transcript changed/i.test(response.error)) setConflict(true);
      }
    }, 400);
    return () => window.clearTimeout(timer);
  }, [canonicalTranscript, conflict, customPrompt, editBaseRevision, hydrated, outputFormat, selectedPoints, state, transcript]);
  reactExports.useEffect(() => {
    if (notice?.kind === "error") errorRef.current?.focus();
  }, [notice]);
  const researchByTopic = reactExports.useMemo(
    () => new Map((state?.topicResearch ?? []).map((item) => [item.topic, item])),
    [state?.topicResearch]
  );
  const wordCount = transcript.trim() ? transcript.trim().split(/\s+/).length : 0;
  const canGenerate = Boolean(state && ["reviewing", "done"].includes(state.status) && transcript.trim().length >= 50 && !conflict);
  const busy = Boolean(state && ["processing", "finalizing", "transcribing", "extracting", "researching", "generating"].includes(state.status));
  const toggleTopic = (topic) => {
    const selected = selectedPoints.includes(topic);
    const next = selected ? selectedPoints.filter((item) => item !== topic) : [...selectedPoints, topic];
    setSelectedPoints(next);
    void chrome.runtime.sendMessage({
      type: selected ? MessageType.TOPIC_DESELECTED : MessageType.TOPIC_SELECTED,
      payload: { topic }
    });
  };
  const useLatestTranscript = () => {
    const latest = state?.transcript ?? canonicalTranscript;
    dirtyRef.current = false;
    setTranscript(latest);
    setCanonicalTranscript(latest);
    setEditBaseRevision(state?.transcriptRevision ?? sessionRef.current.revision);
    setConflict(false);
    setNotice(null);
  };
  const generate = async () => {
    if (!state || !canGenerate) return;
    setNotice(null);
    const edited = transcript !== canonicalTranscript;
    const response = await chrome.runtime.sendMessage({
      type: MessageType.GENERATE_DECK,
      payload: {
        sessionId: state.sessionId,
        transcriptRevision: editBaseRevision,
        transcriptEdited: edited,
        transcript,
        selectedPoints,
        customPrompt: customPrompt.trim(),
        outputFormat
      }
    }).catch((reason) => ({ error: reason instanceof Error ? reason.message : String(reason) }));
    if (response?.error) {
      setNotice({ kind: "error", text: response.error });
      if (/transcript changed/i.test(response.error)) setConflict(true);
    }
  };
  const copyArtifact = async () => {
    if (!state) return;
    const response = await chrome.runtime.sendMessage({ type: MessageType.GET_LAST_HTML, payload: { sessionId: state.sessionId } });
    if (!response?.html) {
      setNotice({ kind: "error", text: response?.error ?? "No generated artifact is available to copy." });
      return;
    }
    try {
      await navigator.clipboard.writeText(response.html);
      setNotice({ kind: "success", text: "Artifact HTML copied." });
    } catch {
      setNotice({ kind: "error", text: "Chrome could not copy the artifact. Download it instead." });
    }
  };
  const downloadArtifact = async () => {
    if (!state) return;
    const response = await chrome.runtime.sendMessage({ type: MessageType.DOWNLOAD_ARTIFACT, payload: { sessionId: state.sessionId } });
    setNotice(response?.ok ? { kind: "success", text: `Download started: ${response.filename}` } : { kind: "error", text: response?.error ?? "Chrome could not download the artifact. Try again." });
  };
  if (!hydrated) return /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "review-shell", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { role: "status", "aria-live": "polite", children: "Restoring your recording..." }) });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "review-shell", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "page-header", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "brand", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: chrome.runtime.getURL("icons/icon48.png"), width: "32", height: "32", alt: "" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Decker" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "provider", children: state ? `${state.provider === "gemini" ? "Gemini" : "OpenAI"} is connected` : "Review" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "intro", "aria-labelledby": "review-title", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "eyebrow", children: "Recording review" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { id: "review-title", ref: headingRef, tabIndex: -1, children: "Shape the transcript into something useful." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Edit the words, choose the topics that matter, then pick an output." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `progress ${busy ? "is-busy" : ""}`, role: "status", "aria-live": "polite", "aria-atomic": "true", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "progress-mark", "aria-hidden": "true" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: state ? progressText(state.status, state.message) : "No saved recording found." }),
      saving && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "save-state", children: "Saving changes..." })
    ] }),
    notice && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: errorRef, tabIndex: notice.kind === "error" ? -1 : void 0, role: notice.kind === "error" ? "alert" : "status", className: `notice ${notice.kind}`, children: notice.text }),
    conflict && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { role: "alert", className: "notice error conflict", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "The transcript changed while you were editing. Load the latest version before generating." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "text-button", onClick: useLatestTranscript, children: "Use latest transcript" })
    ] }),
    (state?.warnings.length ?? 0) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "warning-card", "aria-labelledby": "capture-warnings", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "capture-warnings", children: "Capture warnings" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { children: state?.warnings.map((warning) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: warning }, warning)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "review-grid", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "card transcript-card", "aria-labelledby": "transcript-heading", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-heading", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "step", children: "1" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "transcript-heading", children: "Transcript" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            wordCount.toLocaleString(),
            " words"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "sr-only", htmlFor: "meeting-transcript", children: "Meeting transcript" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            id: "meeting-transcript",
            value: transcript,
            onChange: (event) => {
              dirtyRef.current = event.target.value !== canonicalTranscript;
              setTranscript(event.target.value);
              setNotice(null);
            },
            placeholder: "Your transcript will appear here when processing finishes.",
            spellCheck: true
          }
        ),
        transcript.trim().length > 0 && transcript.trim().length < 50 && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "field-note", children: "Add a little more detail before generating. The transcript needs at least 50 characters." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "side-column", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "card", "aria-labelledby": "topics-heading", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-heading", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "step", children: "2" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "topics-heading", children: "Topics" })
            ] }),
            state?.points?.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "text-button", onClick: () => setSelectedPoints(selectedPoints.length === state.points.length ? [] : [...state.points]), children: selectedPoints.length === state.points.length ? "Clear" : "Select all" }) : null
          ] }),
          state?.points?.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "topic-list", children: state.points.map((topic) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "topic", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: selectedPoints.includes(topic), onChange: () => toggleTopic(topic) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: topic }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("small", { children: researchLabel(researchByTopic.get(topic)) })
            ] })
          ] }, topic)) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "empty-note", children: "No topics were found. You can still generate from the full transcript." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "sr-only", "aria-live": "polite", children: [
            "Research status: ",
            (state?.topicResearch ?? []).map((item) => `${item.topic}: ${researchLabel(item)}`).join(", ") || "No topic research"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "card", "aria-labelledby": "output-heading", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-heading", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "step", children: "3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "output-heading", children: "Output" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { className: "format-list", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { className: "sr-only", children: "Output format" }),
            formatOptions.map((option) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: `format ${outputFormat === option.value ? "selected" : ""}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "radio", name: "output-format", value: option.value, checked: outputFormat === option.value, onChange: () => setOutputFormat(option.value) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: option.label }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("small", { children: option.detail })
              ] })
            ] }, option.value))
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "field-label", htmlFor: "custom-instructions", children: "Custom instructions" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { id: "custom-instructions", className: "instructions", value: customPrompt, onChange: (event) => setCustomPrompt(event.target.value), placeholder: "Example: Put decisions first and name each owner." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "primary", disabled: !canGenerate, onClick: generate, children: state?.status === "done" ? "Generate again" : "Generate artifact" })
        ] }),
        state?.hasHtml && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "card artifact-card", "aria-labelledby": "artifact-heading", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "step", children: "4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "artifact-heading", children: "Artifact ready" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "The generated HTML is saved with this recovery session." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "action-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "secondary", onClick: copyArtifact, children: "Copy HTML" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "primary", onClick: downloadArtifact, children: "Download HTML" })
          ] })
        ] })
      ] })
    ] })
  ] });
}
createRoot(document.getElementById("review-root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Review, {}) })
);
