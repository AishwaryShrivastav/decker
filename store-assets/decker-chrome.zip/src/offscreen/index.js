import { M as MessageType } from "../../chunks/types-gkKYuXIj.js";
import { w as waitForRetry } from "../../chunks/capture-DNZ7mw4Q.js";
class AudioDelivery {
  constructor(sessionId2, send, sleep = waitForRetry) {
    this.sessionId = sessionId2;
    this.send = send;
    this.sleep = sleep;
  }
  chain = Promise.resolve();
  sequence = 0;
  missing = [];
  finalPayload;
  async deliver(type, payload) {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await this.send(type, payload);
        if (!response?.ok) throw new Error("Audio was not saved");
        return;
      } catch (error) {
        if (attempt === 2) throw error;
        await this.sleep(1e3 * 2 ** attempt);
      }
    }
  }
  enqueue(convert, mimeType) {
    const sequence = this.sequence++;
    this.chain = this.chain.then(async () => {
      try {
        const base64 = await convert();
        if (!base64) throw new Error("Empty audio");
        await this.deliver("AUDIO_CHUNK", { sessionId: this.sessionId, sequence, base64, mimeType });
      } catch {
        this.missing.push(sequence);
      }
    });
  }
  finish(convert, mimeType) {
    this.chain = this.chain.then(async () => {
      let base64 = "";
      try {
        base64 = await convert();
      } catch {
        this.missing.push(this.sequence);
      }
      this.finalPayload = { sessionId: this.sessionId, sequence: this.sequence++, base64, mimeType, missingSequences: this.missing };
      await this.resendFinal();
    });
    return this.chain;
  }
  async resendFinal() {
    if (!this.finalPayload) return false;
    await this.deliver("RECORDING_STOPPED", this.finalPayload);
    return true;
  }
}
const SEGMENT_MS = 16e3;
let mediaRecorder = null;
let audioContext = null;
let tabStream = null;
let micStream = null;
let segmentTimer;
let silenceTimer;
let sessionId = "";
let stopping = false;
let finishing = false;
let delivery = null;
function warn(warning) {
  chrome.runtime.sendMessage({ type: MessageType.CAPTURE_WARNING, payload: { sessionId, warning } }).catch(() => {
  });
}
async function releaseSources() {
  clearTimeout(segmentTimer);
  clearTimeout(silenceTimer);
  tabStream?.getTracks().forEach((t) => t.stop());
  micStream?.getTracks().forEach((t) => t.stop());
  tabStream = null;
  micStream = null;
  const context = audioContext;
  audioContext = null;
  if (context && context.state !== "closed") await context.close();
}
async function startRecording(payload) {
  if (mediaRecorder?.state === "recording" || finishing) throw new Error("Audio capture is already active.");
  sessionId = payload.sessionId;
  stopping = false;
  const warnings = [];
  try {
    tabStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        // @ts-expect-error Chrome tab-capture constraints
        mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: payload.streamId }
      },
      video: false
    });
    if (!tabStream.getAudioTracks().some((t) => t.readyState === "live")) {
      throw new Error("No tab audio track was captured. Reopen the Meet tab and try again.");
    }
    try {
      micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!micStream.getAudioTracks().some((t) => t.readyState === "live")) throw new Error("No live microphone");
    } catch {
      micStream?.getTracks().forEach((t) => t.stop());
      micStream = null;
      warnings.push("Microphone unavailable. Only tab audio is being captured; your voice may be missing. Allow microphone access in Settings.");
    }
    if (tabStream.getAudioTracks().some((t) => t.muted)) warnings.push("The tab audio track is muted. Check that meeting audio is playing.");
    audioContext = new AudioContext();
    const tabSource = audioContext.createMediaStreamSource(tabStream);
    const destination = audioContext.createMediaStreamDestination();
    tabSource.connect(destination);
    tabSource.connect(audioContext.destination);
    if (micStream) audioContext.createMediaStreamSource(micStream).connect(destination);
    if (audioContext.state === "suspended") await audioContext.resume();
    if (audioContext.state !== "running") throw new Error("Audio processing did not start. Try starting capture again.");
    for (const track of tabStream.getAudioTracks()) track.onended = () => {
      warn("Tab audio ended. Capture stopped; the end of the meeting may be missing.");
      stopRecording();
    };
    for (const track of micStream?.getAudioTracks() ?? []) track.onended = () => {
      if (!stopping) warn("The microphone disconnected during capture. Your voice may be missing after disconnection.");
    };
    const analyser = audioContext.createAnalyser();
    audioContext.createMediaStreamSource(destination.stream).connect(analyser);
    const samples = new Uint8Array(analyser.fftSize);
    let heardAudio = false;
    let checks = 0;
    const checkSignal = () => {
      if (stopping) return;
      analyser.getByteTimeDomainData(samples);
      heardAudio ||= samples.some((value) => Math.abs(value - 128) > 2);
      if (++checks < 20) silenceTimer = setTimeout(checkSignal, 500);
      else if (!heardAudio) warn("No audio signal was detected during the first 10 seconds. Check meeting sound and microphone access; the transcript may be incomplete.");
    };
    silenceTimer = setTimeout(checkSignal, 500);
    const mimeType = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus"].find((type) => MediaRecorder.isTypeSupported(type));
    if (!mimeType) throw new Error("This browser has no supported audio recording format.");
    delivery = new AudioDelivery(sessionId, (type, data) => chrome.runtime.sendMessage({ type, payload: data }));
    const mixedStream = destination.stream;
    const recordSegment = () => {
      const parts = [];
      const recorder = new MediaRecorder(mixedStream, { mimeType, audioBitsPerSecond: 128e3 });
      mediaRecorder = recorder;
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) parts.push(event.data);
      };
      recorder.onerror = () => {
        warn("The audio recorder failed. Some audio may be missing.");
        stopRecording();
      };
      recorder.onstop = () => {
        clearTimeout(segmentTimer);
        const blob = new Blob(parts, { type: mimeType });
        if (!stopping) {
          delivery.enqueue(() => blobToBase64(blob), mimeType);
          recordSegment();
        } else {
          finishing = true;
          void releaseSources();
          void delivery.finish(() => blob.size ? blobToBase64(blob) : Promise.resolve(""), mimeType).then(() => {
            finishing = false;
          }).catch(() => warn("Final audio delivery was interrupted. Reopen Decker to recover the final segment."));
        }
      };
      recorder.start();
      segmentTimer = setTimeout(() => {
        if (recorder.state !== "inactive") recorder.stop();
      }, SEGMENT_MS);
    };
    recordSegment();
    return warnings;
  } catch (error) {
    stopping = true;
    await releaseSources();
    throw error;
  }
}
function stopRecording() {
  stopping = true;
  clearTimeout(segmentTimer);
  if (mediaRecorder && mediaRecorder.state !== "inactive") mediaRecorder.stop();
}
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1] ?? "");
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  switch (message.type) {
    case MessageType.OFFSCREEN_START:
      startRecording(message.payload).then(
        (warnings) => sendResponse({ ok: true, warnings }),
        (error) => sendResponse({ error: error instanceof Error ? error.message : String(error) })
      );
      return true;
    case MessageType.OFFSCREEN_STOP:
      stopRecording();
      sendResponse({ ok: true });
      return false;
    case MessageType.OFFSCREEN_STATUS:
      sendResponse({ sessionId, active: !stopping && mediaRecorder?.state === "recording", finishing });
      if (finishing) void delivery?.resendFinal().then((sent) => {
        if (sent) finishing = false;
      }).catch(() => {
      });
      return false;
    default:
      return false;
  }
});
