import { M as MessageType } from "../../chunks/types-DtLe3GqC.js";
const CHUNK_BATCH_SIZE = 8;
const MIN_CHUNK_BYTES = 2e4;
let mediaRecorder = null;
let audioChunks = [];
let headerChunk = null;
let mimeType = "audio/webm;codecs=opus";
let audioContext = null;
let tabStream = null;
let micStream = null;
async function startRecording(streamId) {
  try {
    tabStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        // @ts-expect-error: Chrome-specific constraint
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId
        }
      },
      video: false
    });
    try {
      micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (micErr) {
      console.warn("[Decker offscreen] Mic access failed, recording tab only:", micErr);
      micStream = null;
    }
    audioContext = new AudioContext();
    const tabSource = audioContext.createMediaStreamSource(tabStream);
    const destination = audioContext.createMediaStreamDestination();
    tabSource.connect(destination);
    if (micStream) {
      const micSource = audioContext.createMediaStreamSource(micStream);
      micSource.connect(destination);
    }
    tabSource.connect(audioContext.destination);
    if (audioContext.state === "suspended") {
      await audioContext.resume();
    }
    const mixedStream = destination.stream;
    const candidates = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/ogg;codecs=opus"
    ];
    mimeType = candidates.find((t) => MediaRecorder.isTypeSupported(t)) ?? "audio/webm";
    audioChunks = [];
    headerChunk = null;
    mediaRecorder = new MediaRecorder(mixedStream, {
      mimeType,
      audioBitsPerSecond: 128e3
    });
    mediaRecorder.ondataavailable = async (event) => {
      if (event.data.size > 0) {
        audioChunks.push(event.data);
        if (!headerChunk) headerChunk = event.data;
        while (audioChunks.length >= CHUNK_BATCH_SIZE) {
          const batch = audioChunks.splice(0, CHUNK_BATCH_SIZE);
          const parts = batch[0] === headerChunk ? batch : [headerChunk, ...batch];
          const blob = new Blob(parts, { type: mimeType });
          if (blob.size >= MIN_CHUNK_BYTES) {
            const base64 = await blobToBase64(blob);
            if (base64) {
              chrome.runtime.sendMessage({
                type: MessageType.AUDIO_CHUNK,
                payload: { base64, mimeType }
              }).catch((err) => console.warn("[Decker offscreen] AUDIO_CHUNK send failed:", err));
            } else {
              console.warn("[Decker offscreen] blobToBase64 returned empty");
            }
          }
        }
      }
    };
    mediaRecorder.onstop = async () => {
      const parts = headerChunk && audioChunks[0] !== headerChunk ? [headerChunk, ...audioChunks] : audioChunks;
      const blob = new Blob(parts, { type: mimeType });
      console.log("[Decker offscreen] Recording stopped, blob size:", blob.size, "chunks:", audioChunks.length);
      if (audioContext) {
        await audioContext.close();
        audioContext = null;
      }
      tabStream?.getTracks().forEach((t) => t.stop());
      micStream?.getTracks().forEach((t) => t.stop());
      tabStream = null;
      micStream = null;
      if (blob.size < 1e3) {
        console.error("[Decker offscreen] Recording too short or empty — need at least ~1KB of audio");
        chrome.runtime.sendMessage({
          type: MessageType.STATUS_UPDATE,
          payload: { status: "error", message: "Recording too short. Record at least 3–5 seconds of audio." }
        });
        return;
      }
      chrome.runtime.sendMessage({
        type: MessageType.STATUS_UPDATE,
        payload: { status: "finalizing", message: "Preparing audio…" }
      });
      console.log("[Decker offscreen] Converting blob to base64…");
      const base64 = await blobToBase64(blob);
      console.log("[Decker offscreen] Base64 ready, sending RECORDING_STOPPED to background…");
      chrome.runtime.sendMessage({
        type: MessageType.RECORDING_STOPPED,
        payload: { base64, mimeType }
      });
    };
    mediaRecorder.start(2e3);
    console.log(
      "[Decker offscreen] MediaRecorder started",
      micStream ? "(tab + mic)" : "(tab only)",
      "mimeType:",
      mimeType
    );
  } catch (err) {
    console.error("[Decker offscreen] startRecording failed:", err);
    tabStream?.getTracks().forEach((t) => t.stop());
    micStream?.getTracks().forEach((t) => t.stop());
    tabStream = null;
    micStream = null;
    const name = err instanceof Error ? err.name ?? "" : "";
    const msg = err instanceof Error ? err.message : String(err);
    chrome.runtime.sendMessage({
      type: MessageType.STATUS_UPDATE,
      payload: {
        status: "error",
        message: name === "NotAllowedError" ? "Permission denied. Allow microphone and reload the Meet tab, then try again." : msg.includes("not found") || name === "NotFoundError" ? "Microphone not found. Check your device." : `Capture failed: ${msg}`
      }
    });
  }
}
function stopRecording() {
  if (mediaRecorder && mediaRecorder.state !== "inactive") {
    mediaRecorder.stop();
  } else {
    console.warn("[Decker offscreen] stopRecording called but recorder not active");
  }
}
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result;
      const base64 = result?.split(",")[1] ?? "";
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
chrome.runtime.onMessage.addListener((message) => {
  switch (message.type) {
    case MessageType.OFFSCREEN_START: {
      const payload = message.payload;
      startRecording(payload.streamId).catch(console.error);
      break;
    }
    case MessageType.OFFSCREEN_STOP: {
      console.log("[Decker offscreen] OFFSCREEN_STOP received, stopping MediaRecorder…");
      stopRecording();
      break;
    }
  }
});
console.log("[Decker offscreen] Document ready");
