import { M as MessageType } from "../../chunks/types-gkKYuXIj.js";
import { f as freshSession, r as recoverSession, a as addWarning, t as transcriptForGeneration, b as addCaptureNotice, p as processPendingChunks, c as reconcileTopics } from "../../chunks/capture-DNZ7mw4Q.js";
import { r as recordActivation } from "../../chunks/activation-DjBQy3XU.js";
function esc(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function pad2(n) {
  return n.toString().padStart(2, "0");
}
function buildMeetingDoc(data) {
  const now = /* @__PURE__ */ new Date();
  const dateStr = `${now.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}`;
  const topicCount = data.topics.length;
  const tocItems = data.topics.map(
    (t, i) => `<li><a href="#topic-${i + 1}" class="toc-link"><span class="toc-num">${pad2(i + 1)}</span><span>${esc(t.title)}</span></a></li>`
  ).join("\n          ");
  const allActions = [
    ...data.topics.flatMap((t) => (t.actionItems ?? []).map((a) => ({ topic: t.title, action: a }))),
    ...(data.overallActionItems ?? []).map((a) => ({ topic: null, action: a }))
  ];
  const topicSections = data.topics.map((topic, i) => {
    const idx = i + 1;
    const summaryHtml = topic.summary ? `<p class="topic-summary">${esc(topic.summary)}</p>` : "";
    const decisionHtml = topic.keyDecision ? `<div class="decision-card">
              <span class="decision-label">Key Decision</span>
              <p class="decision-text">${esc(topic.keyDecision)}</p>
            </div>` : "";
    const subtopicsHtml = topic.subtopics.length > 0 ? `<ul class="subtopics">
              ${topic.subtopics.map((s) => `<li>${esc(s)}</li>`).join("\n              ")}
            </ul>` : "";
    const actionsHtml = (topic.actionItems ?? []).length > 0 ? `<div class="topic-actions">
              <span class="actions-label">Action Items</span>
              <ul class="action-list">
                ${(topic.actionItems ?? []).map((a) => `<li>${esc(a)}</li>`).join("\n                ")}
              </ul>
            </div>` : "";
    return `    <section id="topic-${idx}" class="topic-section">
        <div class="topic-header">
          <span class="topic-num">${pad2(idx)}</span>
          <h2 class="topic-title">${esc(topic.title)}</h2>
        </div>
        ${summaryHtml}
        ${decisionHtml}
        ${subtopicsHtml}
        ${actionsHtml}
      </section>`;
  }).join("\n\n");
  const actionTableHtml = allActions.length > 0 ? `    <section class="actions-section">
        <h2 class="section-heading">All Action Items</h2>
        <table class="actions-table">
          <thead>
            <tr><th>Action</th><th>Topic</th></tr>
          </thead>
          <tbody>
            ${allActions.map(
    (a) => `<tr><td>${esc(a.action)}</td><td class="topic-ref">${a.topic ? esc(a.topic) : "—"}</td></tr>`
  ).join("\n            ")}
          </tbody>
        </table>
      </section>` : "";
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${esc(data.title)}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg: #080c18;
      --surface: #0d1224;
      --surface2: rgba(255,255,255,0.04);
      --border: rgba(255,255,255,0.07);
      --accent: #818cf8;
      --accent-dim: rgba(99,102,241,0.15);
      --accent-border: rgba(99,102,241,0.35);
      --text: #e2e8f0;
      --text-muted: #64748b;
      --text-dim: #94a3b8;
      --decision: #34d399;
      --decision-dim: rgba(52,211,153,0.1);
      --decision-border: rgba(52,211,153,0.3);
      --font: 'Inter', -apple-system, system-ui, sans-serif;
      --mono: 'JetBrains Mono', 'Fira Code', monospace;
      --max-w: 860px;
      --sidebar: 260px;
    }

    html { scroll-behavior: smooth; }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: var(--font);
      line-height: 1.65;
      min-height: 100vh;
    }

    /* ── LAYOUT ── */
    .layout {
      display: grid;
      grid-template-columns: var(--sidebar) 1fr;
      grid-template-rows: auto 1fr;
      min-height: 100vh;
    }

    /* ── HEADER ── */
    .site-header {
      grid-column: 1 / -1;
      padding: 2.5rem 3rem;
      border-bottom: 1px solid var(--border);
      background: linear-gradient(135deg, #080c18 0%, #0d1224 100%);
    }

    .header-meta {
      font-family: var(--mono);
      font-size: 0.7rem;
      color: var(--text-muted);
      letter-spacing: 0.06em;
      text-transform: uppercase;
      margin-bottom: 0.6rem;
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .header-badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 2px 10px;
      border: 1px solid var(--accent-border);
      border-radius: 99px;
      color: var(--accent);
      background: var(--accent-dim);
      font-size: 0.65rem;
      letter-spacing: 0.08em;
    }

    .site-title {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text);
      letter-spacing: -0.03em;
      line-height: 1.2;
      margin-bottom: 0.5rem;
    }

    .site-subtitle {
      font-size: 0.95rem;
      color: var(--text-dim);
      font-weight: 300;
    }

    .executive-summary {
      margin-top: 1.5rem;
      padding: 1rem 1.25rem;
      background: var(--surface2);
      border: 1px solid var(--border);
      border-left: 3px solid var(--accent);
      border-radius: 0 8px 8px 0;
      font-size: 0.9rem;
      color: var(--text-dim);
      max-width: var(--max-w);
    }

    /* ── SIDEBAR ── */
    .sidebar {
      padding: 2rem 1.5rem;
      border-right: 1px solid var(--border);
      background: var(--surface);
      position: sticky;
      top: 0;
      height: 100vh;
      overflow-y: auto;
    }

    .sidebar-label {
      font-family: var(--mono);
      font-size: 0.65rem;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--text-muted);
      margin-bottom: 1rem;
    }

    .toc-list {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .toc-link {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.5rem 0.75rem;
      border-radius: 6px;
      text-decoration: none;
      color: var(--text-dim);
      font-size: 0.82rem;
      transition: background 0.15s, color 0.15s;
    }

    .toc-link:hover {
      background: var(--surface2);
      color: var(--text);
    }

    .toc-num {
      font-family: var(--mono);
      font-size: 0.65rem;
      color: var(--accent);
      flex-shrink: 0;
    }

    /* ── MAIN CONTENT ── */
    .main-content {
      padding: 2.5rem 3rem;
      max-width: var(--max-w);
    }

    /* ── TOPIC SECTION ── */
    .topic-section {
      margin-bottom: 3.5rem;
      padding-bottom: 3rem;
      border-bottom: 1px solid var(--border);
    }

    .topic-section:last-of-type {
      border-bottom: none;
    }

    .topic-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      margin-bottom: 1.25rem;
    }

    .topic-num {
      font-family: var(--mono);
      font-size: 0.7rem;
      font-weight: 500;
      color: var(--accent);
      background: var(--accent-dim);
      border: 1px solid var(--accent-border);
      padding: 3px 10px;
      border-radius: 6px;
      flex-shrink: 0;
    }

    .topic-title {
      font-size: 1.35rem;
      font-weight: 600;
      color: var(--text);
      letter-spacing: -0.02em;
      line-height: 1.3;
    }

    .topic-summary {
      font-size: 0.9rem;
      color: var(--text-dim);
      line-height: 1.7;
      margin-bottom: 1.25rem;
    }

    /* Decision card */
    .decision-card {
      background: var(--decision-dim);
      border: 1px solid var(--decision-border);
      border-radius: 8px;
      padding: 1rem 1.25rem;
      margin-bottom: 1.25rem;
    }

    .decision-label {
      display: block;
      font-family: var(--mono);
      font-size: 0.62rem;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--decision);
      margin-bottom: 0.4rem;
    }

    .decision-text {
      font-size: 0.9rem;
      font-weight: 500;
      color: var(--text);
    }

    /* Subtopics */
    .subtopics {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      margin-bottom: 1.25rem;
    }

    .subtopics li {
      position: relative;
      padding: 0.55rem 0.9rem 0.55rem 1rem;
      background: var(--surface2);
      border: 1px solid var(--border);
      border-radius: 6px;
      font-size: 0.85rem;
      color: var(--text);
      line-height: 1.5;
    }

    .subtopics li::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 3px;
      background: linear-gradient(180deg, var(--accent) 0%, #a5b4fc 100%);
      border-radius: 3px 0 0 3px;
    }

    /* Topic action items */
    .topic-actions {
      margin-top: 0.25rem;
    }

    .actions-label {
      display: block;
      font-family: var(--mono);
      font-size: 0.62rem;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--text-muted);
      margin-bottom: 0.5rem;
    }

    .action-list {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 0.35rem;
    }

    .action-list li {
      font-size: 0.82rem;
      color: var(--text-dim);
      padding: 0.3rem 0.6rem;
      background: rgba(255,255,255,0.02);
      border-radius: 4px;
    }

    .action-list li::before {
      content: '→ ';
      color: var(--accent);
    }

    /* ── ALL ACTIONS TABLE ── */
    .actions-section {
      margin-top: 1rem;
    }

    .section-heading {
      font-size: 1.1rem;
      font-weight: 600;
      color: var(--text);
      margin-bottom: 1.25rem;
      letter-spacing: -0.01em;
    }

    .actions-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.85rem;
    }

    .actions-table th {
      text-align: left;
      padding: 0.6rem 0.9rem;
      background: var(--surface2);
      border: 1px solid var(--border);
      font-weight: 500;
      color: var(--text-dim);
      font-family: var(--mono);
      font-size: 0.68rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }

    .actions-table td {
      padding: 0.65rem 0.9rem;
      border: 1px solid var(--border);
      color: var(--text);
      vertical-align: top;
    }

    .actions-table tr:hover td {
      background: var(--surface2);
    }

    .topic-ref {
      color: var(--text-muted);
      font-size: 0.8rem;
      white-space: nowrap;
    }

    /* ── FOOTER ── */
    .site-footer {
      grid-column: 1 / -1;
      padding: 1.5rem 3rem;
      border-top: 1px solid var(--border);
      text-align: center;
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .site-footer a {
      color: var(--accent);
      text-decoration: none;
    }

    /* ── RESPONSIVE ── */
    @media (max-width: 768px) {
      .layout {
        grid-template-columns: 1fr;
      }
      .sidebar {
        display: none;
      }
      .main-content {
        padding: 1.5rem;
      }
      .site-header {
        padding: 1.5rem;
      }
      .site-title {
        font-size: 1.5rem;
      }
    }
  </style>
</head>
<body>
  <div class="layout">
    <!-- Header -->
    <header class="site-header">
      <div class="header-meta">
        <span>${esc(dateStr)}</span>
        <span class="header-badge">⚡ Decker · AI Generated</span>
        <span>${topicCount} topic${topicCount !== 1 ? "s" : ""}</span>
      </div>
      <h1 class="site-title">${esc(data.title)}</h1>
      ${data.subtitle ? `<p class="site-subtitle">${esc(data.subtitle)}</p>` : ""}
      ${data.summary ? `<p class="executive-summary">${esc(data.summary)}</p>` : ""}
    </header>

    <!-- Sidebar TOC -->
    <aside class="sidebar">
      <div class="sidebar-label">Topics</div>
      <ol class="toc-list">
        ${tocItems}
      </ol>
    </aside>

    <!-- Main content -->
    <main class="main-content">
${topicSections}

${actionTableHtml}
    </main>

    <!-- Footer -->
    <footer class="site-footer">
      Generated with <a href="https://decker.so" target="_blank">Decker</a> · ${esc(dateStr)}
    </footer>
  </div>
</body>
</html>`;
}
const EXTRACT_POINTS_SYSTEM = `You are a product meeting analyst. Given a (possibly partial) meeting transcript between product owners, engineers, or tech leads, extract the 5–12 most important discussion points, decisions, or product ideas covered so far.

Each point must be specific and actionable — not generic. Under 15 words.

Return ONLY a JSON object: {"points":["specific point 1","specific point 2"]}

If the transcript is too short, return {"points":[]}.`;
function extractPointsUser(transcript) {
  return `Extract the key discussion points.

<transcript>
${transcript}
</transcript>`;
}
const RESEARCH_SYSTEM = `You are a product research assistant embedded in a live meeting. A product owner or tech lead just discussed a topic. Provide fast, useful research context that will enrich the output artifact.

Return ONLY a JSON object:
{
  "context": "1–2 sentences of relevant background or industry context",
  "keyInsight": "The most important takeaway, decision, or implication from this topic",
  "subtopics": ["specific sub-point 1", "specific sub-point 2", "specific sub-point 3"]
}

Be concrete. Use facts from the transcript. Every subtopic under 10 words.`;
function researchUser(topic, transcript) {
  return `Research this meeting topic: "${topic}"

<transcript>
${transcript}
</transcript>`;
}
const DOC_SYSTEM = `You are a senior product manager synthesising a meeting into a polished product brief.

Return ONLY a JSON object (no markdown fences):
{
  "title": "meeting title (≤8 words)",
  "subtitle": "optional: date, team, or one-line context",
  "summary": "2–3 sentence executive summary — the core idea and key outcome",
  "topics": [
    {
      "title": "topic title (≤8 words)",
      "summary": "2–3 sentences on what was discussed and decided",
      "keyDecision": "the specific decision or outcome, or null",
      "subtopics": ["detailed point with full context — full sentences preferred"],
      "actionItems": ["action: @owner or team"]
    }
  ],
  "overallActionItems": ["cross-cutting action item"]
}

Rules: Be specific — use real names, numbers, dates. Full sentences in subtopics. Empty arrays where no data.`;
function docUser(transcript, selectedTopics, customPrompt, research) {
  const topicsSection = selectedTopics.length > 0 ? `
<selected_topics>
${selectedTopics.map((t) => `- ${t}`).join("\n")}
</selected_topics>` : "";
  const researchSection = research.length > 0 ? `
<research_context>
${research.filter((r) => r.summary || r.keyInsight).map((r) => `Topic: ${r.topic}
Context: ${r.summary ?? ""}
Key insight: ${r.keyInsight ?? ""}
Sub-points: ${(r.subtopics ?? []).join(", ")}`).join("\n\n")}
</research_context>` : "";
  const customSection = customPrompt.trim() ? `
<additional_instructions>
${customPrompt.trim()}
</additional_instructions>` : "";
  return `Create a product brief from this meeting.${topicsSection}${researchSection}${customSection}

<transcript>
${transcript}
</transcript>`;
}
const PRESENTATION_SYSTEM = `You are an expert at creating stunning, self-contained HTML presentations for product teams.
A product owner or tech lead just had a meeting and will show this presentation LIVE at the end of the call.
Build something that creates an "Aha moment" — beautiful, professional, immediately impressive.

Requirements:
- Return ONLY the raw HTML — no markdown fences, no explanation, nothing else
- Completely self-contained: all CSS and JS inline (Google Fonts @import is fine)
- NO external CDN for frameworks — pure HTML/CSS/JS only
- Full-viewport slides, one visible at a time
- Navigation: on-screen ← → buttons AND left/right/space keyboard shortcuts
- Smooth CSS transitions between slides (fade or slide)
- Progress bar at bottom + slide counter (e.g. "3 / 8")
- Design: dark theme, gradient backgrounds, beautiful typography (Inter or similar)
- Title slide: big impactful headline, subtitle, context
- Content slides: clear heading, 3–5 bullet points styled as elegant cards or list items
- Use callout boxes for key decisions, highlight numbers/metrics in large type
- Last slide: Action Items with owner names
- Use REAL content from the meeting — actual decisions, names, numbers, product names
- Make it something the team is proud to share in the chat before the call ends`;
function presentationUser(transcript, selectedTopics, customPrompt, research) {
  const topicsSection = selectedTopics.length > 0 ? `
<selected_topics>
${selectedTopics.map((t) => `- ${t}`).join("\n")}
</selected_topics>` : "";
  const researchSection = research.length > 0 ? `
<research_context>
${research.filter((r) => r.summary || r.keyInsight).map((r) => `Topic: ${r.topic}
Insight: ${r.keyInsight ?? ""}
Points: ${(r.subtopics ?? []).join(", ")}`).join("\n\n")}
</research_context>` : "";
  const customSection = customPrompt.trim() ? `
<additional_instructions>
${customPrompt.trim()}
</additional_instructions>` : "";
  return `Build a presentation from this product meeting. Show it at the end of the call.${topicsSection}${researchSection}${customSection}

<transcript>
${transcript}
</transcript>`;
}
const DISCUSSION_SPA_SYSTEM = `You are an expert product designer building a shareable product brief website from a meeting.
This is NOT meeting notes. Build a full single-page website that presents the ideas discussed as a polished, living document — something you'd share with the whole team or a stakeholder.

Think: a mini product site for the thing that was discussed.

Requirements:
- Return ONLY the raw HTML — no markdown fences, no explanation
- Completely self-contained (all CSS and JS inline, Google Fonts allowed)
- Sticky navigation header with section links + smooth scroll
- Hero section: big headline capturing the core idea or decision, 2-line description
- One section per major topic: rich content, visual hierarchy, real insights from research
- Use cards, callout boxes, decision highlights, metric callouts where appropriate
- Beautiful typography and spacing (Inter or similar, Google Fonts)
- Dark theme preferred — use gradients, subtle borders, accent colors
- Mobile responsive
- Footer with date and "Built with Decker"
- Use REAL content — actual product names, decisions, people, numbers from the meeting
- The result should feel like a real product brief or spec you'd be proud to share externally`;
function discussionSpaUser(transcript, selectedTopics, customPrompt, research) {
  const topicsSection = selectedTopics.length > 0 ? `
<selected_topics>
${selectedTopics.map((t) => `- ${t}`).join("\n")}
</selected_topics>` : "";
  const researchSection = research.length > 0 ? `
<research_context>
${research.filter((r) => r.summary || r.keyInsight).map((r) => `Topic: ${r.topic}
Context: ${r.summary ?? ""}
Key insight: ${r.keyInsight ?? ""}
Sub-points: ${(r.subtopics ?? []).join(", ")}`).join("\n\n")}
</research_context>` : "";
  const customSection = customPrompt.trim() ? `
<additional_instructions>
${customPrompt.trim()}
</additional_instructions>` : "";
  return `Build a product brief website from this meeting discussion.${topicsSection}${researchSection}${customSection}

<transcript>
${transcript}
</transcript>`;
}
const PROTOTYPE_SYSTEM = `You are a senior product engineer sitting in on a product meeting. The team just spent an hour discussing a product idea, feature, or system. Now build it.

Create a complete, self-contained HTML prototype that demonstrates the actual product concept discussed.
This is what you show at the end of the call instead of saying "I'll send a follow-up."
It should create an "Aha moment" — when the team sees it, they say "yes, that's exactly it."

YOU decide what to build: an app interface, a dashboard, a tool, a workflow UI, a data view — whatever best brings the meeting's ideas to life as an interactive product.

Requirements:
- Return ONLY the raw HTML — no markdown fences, no explanation, nothing else
- Completely self-contained: all CSS and JS inline (Google Fonts @import allowed)
- Functional interactions: buttons respond, tabs switch, forms work (even with mock data)
- Use REAL product context: actual feature names, real data from the meeting, real user flows discussed
- Looks like a real product — not a wireframe, not a demo placeholder
- Beautiful, polished UI — the kind you'd show a stakeholder or investor
- Dark or light theme — choose what fits the product context
- Must be immediately clickable and demonstrable on a live call

This is the MVP of what was discussed. Make it real.`;
function prototypeUser(transcript, selectedTopics, customPrompt, research) {
  const topicsSection = selectedTopics.length > 0 ? `
<selected_topics>
${selectedTopics.map((t) => `- ${t}`).join("\n")}
</selected_topics>` : "";
  const researchSection = research.length > 0 ? `
<research_context>
${research.filter((r) => r.summary || r.keyInsight).map((r) => `Topic: ${r.topic}
Context: ${r.summary ?? ""}
Key insight: ${r.keyInsight ?? ""}
Sub-points: ${(r.subtopics ?? []).join(", ")}`).join("\n\n")}
</research_context>` : "";
  const customSection = customPrompt.trim() ? `
<additional_instructions>
${customPrompt.trim()}
</additional_instructions>` : "";
  return `Build the product prototype from this meeting. Show it live at the end of the call.${topicsSection}${researchSection}${customSection}

<transcript>
${transcript}
</transcript>`;
}
let database;
function openDatabase() {
  return database ??= new Promise((resolve, reject) => {
    const request = indexedDB.open("decker-capture", 1);
    request.onupgradeneeded = () => request.result.createObjectStore("session");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function loadSession() {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const request = db.transaction("session").objectStore("session").get("current");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
let writes = Promise.resolve();
function saveSession(state) {
  const snapshot = structuredClone(state);
  const next = writes.catch(() => {
  }).then(async () => {
    const db = await openDatabase();
    await new Promise((resolve, reject) => {
      const tx = db.transaction("session", "readwrite");
      tx.objectStore("session").put(snapshot, "current");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error("Session save aborted"));
    });
  });
  writes = next;
  return next;
}
const OPENAI_API_BASE = "https://api.openai.com/v1";
const GPT_MINI = "gpt-4o-mini";
const GPT_FULL = "gpt-4o";
let session = freshSession();
let chunkProcessing = null;
let finalizing = null;
let isExtractingTopics = false;
let openaiKey = "";
const topicResearchMap = /* @__PURE__ */ new Map();
const researchInProgress = /* @__PURE__ */ new Set();
const DEBUG_LOG_KEY = "deckerDebugLog";
async function debugLog(msg) {
  const entry = `[${(/* @__PURE__ */ new Date()).toISOString().slice(11, 23)}] ${msg}`;
  console.log("[Decker]", msg);
  chrome.storage.local.get(DEBUG_LOG_KEY, (r) => {
    const log = r[DEBUG_LOG_KEY] ?? [];
    log.push(entry);
    chrome.storage.local.set({ [DEBUG_LOG_KEY]: log.slice(-15) });
  });
}
async function persist() {
  session.research = Array.from(topicResearchMap.values());
  await saveSession(session);
}
const ready = (async () => {
  const [settings, saved] = await Promise.all([
    chrome.storage.local.get(["openaiKey"]),
    loadSession()
  ]);
  openaiKey = typeof settings.openaiKey === "string" ? settings.openaiKey.trim() : "";
  if (saved) session = recoverSession(saved);
  session.research.forEach((r) => topicResearchMap.set(r.topic, r));
})();
async function resumeSession() {
  await ready;
  if (["recording", "processing", "finalizing", "transcribing", "extracting"].includes(session.status)) {
    let capture;
    try {
      capture = await chrome.runtime.sendMessage({ type: MessageType.OFFSCREEN_STATUS });
    } catch {
    }
    if (!session.finalReceived && (capture?.sessionId !== session.id || !capture.active && !capture.finishing)) {
      addWarning(session, "Capture was interrupted. Audio after the last saved segment may be missing.");
      session.finalReceived = true;
      session.status = "processing";
      await persist();
    }
    if (session.finalReceived) void finishSession();
    else void processChunkQueue().catch(reportQueueFailure);
  }
}
const MIME_TO_EXT = {
  "audio/webm": "webm",
  "audio/ogg": "ogg",
  "audio/mp4": "mp4",
  "audio/mpeg": "mp3",
  "audio/wav": "wav",
  "audio/flac": "flac"
};
async function openaiTranscribe(audioBlob) {
  const baseMime = audioBlob.type.split(";")[0]?.trim() || "audio/webm";
  const ext = MIME_TO_EXT[baseMime] ?? "webm";
  const file = new File([audioBlob], `audio.${ext}`, { type: baseMime });
  const formData = new FormData();
  formData.append("file", file);
  formData.append("model", "whisper-1");
  formData.append("language", "en");
  if (!openaiKey) throw new Error("No OpenAI key set — add it in Decker settings (⚙) for Whisper transcription.");
  const res = await fetch(`${OPENAI_API_BASE}/audio/transcriptions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${openaiKey}` },
    body: formData,
    signal: AbortSignal.timeout(2e4)
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Whisper error ${res.status}: ${err}`);
  }
  const data = await res.json();
  return typeof data.text === "string" ? data.text.trim() : "";
}
async function llmComplete(systemPrompt, userMessage, model = "mini") {
  if (!openaiKey) throw new Error("No OpenAI key set — add it in Decker settings (⚙).");
  const modelId = model === "mini" ? GPT_MINI : GPT_FULL;
  const res = await fetch(`${OPENAI_API_BASE}/chat/completions`, {
    method: "POST",
    signal: AbortSignal.timeout(6e4),
    headers: {
      Authorization: `Bearer ${openaiKey}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      max_tokens: 2048,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ]
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`OpenAI ${modelId} error ${res.status}: ${err}`);
  }
  const data = await res.json();
  return data.choices[0]?.message?.content ?? "{}";
}
async function llmStream(systemPrompt, userMessage, model = "full", onProgress) {
  if (!openaiKey) throw new Error("No OpenAI key set — add it in Decker settings (⚙).");
  const modelId = model === "mini" ? GPT_MINI : GPT_FULL;
  const res = await fetch(`${OPENAI_API_BASE}/chat/completions`, {
    method: "POST",
    signal: AbortSignal.timeout(6e4),
    headers: {
      Authorization: `Bearer ${openaiKey}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      max_tokens: 16384,
      stream: true,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ]
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`OpenAI ${modelId} stream error ${res.status}: ${err}`);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let fullText = "";
  let buffer = "";
  let tokenCount = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const event = JSON.parse(data);
          const deltaText = event.choices?.[0]?.delta?.content;
          if (deltaText) {
            fullText += deltaText;
            tokenCount++;
            if (tokenCount % 100 === 0) onProgress?.(tokenCount);
          }
        } catch {
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
  return fullText;
}
async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  if (existing.length > 0) return;
  await chrome.offscreen.createDocument({
    url: chrome.runtime.getURL("src/offscreen/index.html"),
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "Recording tab audio via MediaRecorder"
  });
}
async function closeOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  if (existing.length === 0) return;
  await chrome.offscreen.closeDocument();
}
function broadcastStatus(status, message, extra) {
  session.status = status;
  session.message = message;
  const payload = {
    status,
    message,
    ...extra,
    sessionId: session.id,
    transcriptRevision: session.transcriptRevision,
    warnings: session.warnings,
    selectedPoints: session.selectedPoints
  };
  void persist().catch(() => {
    const warning = "Session recovery could not be saved. Keep Decker open and copy the transcript before leaving.";
    addWarning(session, warning);
    chrome.runtime.sendMessage({
      type: MessageType.STATUS_UPDATE,
      payload: { ...payload, warnings: session.warnings }
    }).catch(() => {
    });
  });
  chrome.runtime.sendMessage({ type: MessageType.STATUS_UPDATE, payload }).catch(() => {
  });
}
function broadcastResearchUpdate() {
  broadcastStatus(session.status, session.message, {
    topicResearch: Array.from(topicResearchMap.values())
  });
}
async function updateLiveTopics() {
  if (isExtractingTopics || session.transcript.length < 100) return;
  isExtractingTopics = true;
  const id = session.id;
  try {
    const raw = await llmComplete(EXTRACT_POINTS_SYSTEM, extractPointsUser(session.transcript));
    const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
    const parsed = JSON.parse(cleaned);
    const newPoints = Array.isArray(parsed.points) ? parsed.points.filter((p) => typeof p === "string").slice(0, 12) : [];
    if (id === session.id && session.status === "recording" && newPoints.length > 0) {
      reconcileTopics(session, newPoints);
      debugLog(`Live topics updated: ${newPoints.length} topics`);
      broadcastStatus("recording", void 0, {
        transcript: session.transcript,
        points: session.points,
        topicResearch: Array.from(topicResearchMap.values())
      });
    }
  } catch (err) {
    debugLog(`Live topic extraction failed: ${err instanceof Error ? err.message : String(err)}`);
  } finally {
    isExtractingTopics = false;
  }
}
async function startTopicResearch(topic) {
  if (researchInProgress.has(topic)) return;
  researchInProgress.add(topic);
  const id = session.id;
  topicResearchMap.set(topic, { topic, status: "researching" });
  broadcastResearchUpdate();
  const transcript = session.transcript;
  try {
    const raw = await llmComplete(RESEARCH_SYSTEM, researchUser(topic, transcript));
    const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
    const parsed = JSON.parse(cleaned);
    if (id !== session.id) return;
    topicResearchMap.set(topic, {
      topic,
      status: "done",
      summary: typeof parsed.context === "string" ? parsed.context : void 0,
      keyInsight: typeof parsed.keyInsight === "string" ? parsed.keyInsight : void 0,
      subtopics: Array.isArray(parsed.subtopics) ? parsed.subtopics.filter((s) => typeof s === "string").slice(0, 5) : []
    });
    debugLog(`Research done for: "${topic}"`);
  } catch (err) {
    if (id !== session.id) return;
    debugLog(`Research failed for "${topic}": ${err instanceof Error ? err.message : String(err)}`);
    topicResearchMap.set(topic, { topic, status: "error" });
  } finally {
    if (id === session.id) researchInProgress.delete(topic);
  }
  if (id === session.id) broadcastResearchUpdate();
}
function base64ToBlob(base64, mimeType) {
  const bytes = atob(base64);
  const buf = new Uint8Array(bytes.length);
  for (let i = 0; i < bytes.length; i++) buf[i] = bytes.charCodeAt(i);
  return new Blob([buf], { type: mimeType });
}
function stripHtmlFences(raw) {
  return raw.replace(/^```html\s*/i, "").replace(/\s*```$/i, "").trim();
}
function assertValidHtml(html, label) {
  const lower = html.toLowerCase();
  if (!lower.startsWith("<!") && !lower.startsWith("<html")) {
    throw new Error(`The model did not return valid HTML for the ${label}. Try again.`);
  }
}
async function transcribeChunk(base64, mimeType) {
  return openaiTranscribe(base64ToBlob(base64, mimeType));
}
function reportQueueFailure() {
  addWarning(session, "Pending audio could not be saved. Keep the session open and copy the transcript before leaving.");
  broadcastStatus(session.status, session.message, { transcript: session.transcript });
}
function processChunkQueue() {
  if (chunkProcessing) return chunkProcessing;
  chunkProcessing = processPendingChunks(
    session,
    (chunk) => transcribeChunk(chunk.base64, chunk.mimeType),
    persist,
    void 0,
    () => {
      broadcastStatus(session.status, session.message, { transcript: session.transcript });
      if (session.status === "recording" && session.transcriptRevision % 3 === 0) void updateLiveTopics();
    }
  ).finally(() => {
    chunkProcessing = null;
  });
  return chunkProcessing;
}
function checkKey() {
  if (!openaiKey.trim()) throw new Error("Add and save an OpenAI key in Settings before recording.");
}
async function startRecordingWithStream(tabId, streamId) {
  checkKey();
  if (!["idle", "done", "error", "reviewing"].includes(session.status) || chunkProcessing || finalizing) {
    throw new Error("A capture or generation is already in progress.");
  }
  const tab = await chrome.tabs.get(tabId);
  if (!tab.url || new URL(tab.url).hostname !== "meet.google.com") throw new Error("Open a Google Meet tab first.");
  session = freshSession();
  session.tabId = tabId;
  session.status = "processing";
  topicResearchMap.clear();
  researchInProgress.clear();
  await persist();
  try {
    await ensureOffscreenDocument();
    const response = await chrome.runtime.sendMessage({
      type: MessageType.OFFSCREEN_START,
      payload: { streamId, sessionId: session.id }
    });
    if (!response?.ok) throw new Error(response?.error ?? "Audio capture did not start.");
    response.warnings?.forEach((w) => addWarning(session, w));
    broadcastStatus("recording");
    void recordActivation("recording_started").catch(() => {
    });
  } catch (error) {
    broadcastStatus("error", error instanceof Error ? error.message : String(error));
    await closeOffscreenDocument();
    throw error;
  }
}
async function stopRecording() {
  if (session.status !== "recording") return;
  broadcastStatus("processing", "Finishing audio capture...");
  try {
    const response = await chrome.runtime.sendMessage({ type: MessageType.OFFSCREEN_STOP });
    if (!response?.ok) throw new Error("Recorder is unavailable");
  } catch {
    addWarning(session, "Capture ended unexpectedly. Audio after the last saved segment may be missing.");
    session.finalReceived = true;
    await persist();
    void finishSession();
  }
}
function finishSession() {
  if (finalizing) return finalizing;
  finalizing = runPhase1().finally(() => {
    finalizing = null;
  });
  return finalizing;
}
async function runPhase1() {
  try {
    broadcastStatus("transcribing", "Finishing transcription...");
    await processChunkQueue();
    broadcastStatus("extracting", "Extracting discussion topics...", { transcript: session.transcript });
    try {
      if (session.transcript.trim()) {
        const raw = await llmComplete(EXTRACT_POINTS_SYSTEM, extractPointsUser(session.transcript));
        const parsed = parseJsonResponse(raw);
        const points = Array.isArray(parsed.points) ? parsed.points.filter((p) => typeof p === "string").slice(0, 12) : [];
        if (points.length) reconcileTopics(session, points);
      }
    } catch {
      addWarning(session, "Topic extraction failed. The transcript is available for review; you can still generate a document.");
    }
    if (!session.transcript.trim()) addWarning(session, "No speech was transcribed. Check tab audio and microphone access, or paste a transcript.");
    broadcastStatus("reviewing", void 0, {
      transcript: session.transcript,
      points: session.points,
      topicResearch: Array.from(topicResearchMap.values())
    });
    await persist();
    if (session.transcript.trim()) void recordActivation("transcript_ready").catch(() => {
    });
    await closeOffscreenDocument();
  } catch {
    broadcastStatus("reviewing", "Recovery storage failed. Copy your transcript before leaving.", { transcript: session.transcript });
  }
}
function parseJsonResponse(raw) {
  const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
  return JSON.parse(cleaned);
}
async function runPhase2(selectedPoints, customPrompt, transcriptEdit, outputFormat) {
  const transcript = transcriptForGeneration(session, transcriptEdit).trim();
  if (!transcript) {
    broadcastStatus("error", "No transcript available — please record again");
    return;
  }
  if (transcript.length < 50) {
    broadcastStatus("error", "Transcript too short (need 50+ characters)");
    return;
  }
  const format = outputFormat ?? "doc";
  try {
    if (selectedPoints.length > 0) {
      const needsResearch = selectedPoints.filter(
        (t) => !topicResearchMap.has(t) || topicResearchMap.get(t)?.status === "error"
      );
      if (needsResearch.length > 0) {
        broadcastStatus("researching", `Researching ${needsResearch.length} topic${needsResearch.length > 1 ? "s" : ""}…`);
        await Promise.all(needsResearch.map((t) => startTopicResearch(t)));
      }
    }
    broadcastStatus(
      "generating",
      format === "prototype" ? "Building your prototype…" : format === "doc" ? "Writing your document…" : format === "presentation" ? "Building your presentation…" : "Building your discussion site…"
    );
    const researchContext = selectedPoints.map((t) => topicResearchMap.get(t)).filter((r) => !!r && r.status === "done").map((r) => ({ topic: r.topic, summary: r.summary, keyInsight: r.keyInsight, subtopics: r.subtopics }));
    let html;
    if (format === "prototype") {
      let tokenCount = 0;
      html = await llmStream(
        PROTOTYPE_SYSTEM,
        prototypeUser(transcript, selectedPoints, customPrompt, researchContext),
        "full",
        (t) => {
          tokenCount = t;
          broadcastStatus("generating", `Building prototype… (~${Math.round(tokenCount / 4)} words)`);
        }
      );
      html = stripHtmlFences(html);
      assertValidHtml(html, "prototype");
    } else if (format === "doc") {
      let tokenCount = 0;
      const rawJson = await llmStream(
        DOC_SYSTEM,
        docUser(transcript, selectedPoints, customPrompt, researchContext),
        "full",
        (t) => {
          tokenCount = t;
          broadcastStatus("generating", `Writing your document… (~${Math.round(tokenCount / 4)} words)`);
        }
      );
      const parsed = parseJsonResponse(rawJson);
      const rawTopics = Array.isArray(parsed.topics) ? parsed.topics : [];
      const validTopics = rawTopics.slice(0, 12).filter((t) => t !== null && typeof t === "object").map((t) => ({
        title: typeof t.title === "string" ? t.title : "Topic",
        summary: typeof t.summary === "string" ? t.summary : "",
        keyDecision: t.keyDecision && typeof t.keyDecision === "string" ? t.keyDecision : null,
        subtopics: Array.isArray(t.subtopics) ? t.subtopics.filter((s) => typeof s === "string").slice(0, 8) : [],
        actionItems: Array.isArray(t.actionItems) ? t.actionItems.filter((a) => typeof a === "string").slice(0, 6) : []
      })).filter((t) => t.subtopics.length > 0 || t.summary.length > 0);
      const docData = {
        title: typeof parsed.title === "string" ? parsed.title : "Meeting Notes",
        subtitle: typeof parsed.subtitle === "string" ? parsed.subtitle : void 0,
        summary: typeof parsed.summary === "string" ? parsed.summary : void 0,
        topics: validTopics.length > 0 ? validTopics : [{ title: "Summary", summary: "Add content from transcript", subtopics: [] }],
        overallActionItems: Array.isArray(parsed.overallActionItems) ? parsed.overallActionItems.filter((a) => typeof a === "string").slice(0, 10) : []
      };
      html = buildMeetingDoc(docData);
    } else if (format === "notes") {
      let tokenCount = 0;
      html = await llmStream(
        DISCUSSION_SPA_SYSTEM,
        discussionSpaUser(transcript, selectedPoints, customPrompt, researchContext),
        "full",
        (t) => {
          tokenCount = t;
          broadcastStatus("generating", `Building discussion site… (~${Math.round(tokenCount / 4)} words)`);
        }
      );
      html = stripHtmlFences(html);
      assertValidHtml(html, "discussion site");
    } else {
      let tokenCount = 0;
      html = await llmStream(
        PRESENTATION_SYSTEM,
        presentationUser(transcript, selectedPoints, customPrompt, researchContext),
        "full",
        (t) => {
          tokenCount = t;
          broadcastStatus("generating", `Building presentation… (~${Math.round(tokenCount / 4)} words)`);
        }
      );
      html = stripHtmlFences(html);
      assertValidHtml(html, "presentation");
    }
    html = addCaptureNotice(html, session.warnings);
    session.html = html;
    await persist();
    const prefix = format === "prototype" ? "decker-prototype" : format === "doc" ? "decker-doc" : format === "notes" ? "decker-notes" : "decker-deck";
    const filename = `${prefix}-${Date.now()}.html`;
    const dataUrl = `data:text/html;charset=utf-8,${encodeURIComponent(html)}`;
    await chrome.downloads.download({ url: dataUrl, filename, saveAs: false });
    void recordActivation("output_generated").catch(() => {
    });
    broadcastStatus("done", `Saved as ${filename}`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    debugLog(`runPhase2 FAILED: ${msg}`);
    broadcastStatus("reviewing", msg, { transcript: session.transcript, points: session.points });
  }
}
async function handleMessage(msg, sender) {
  await ready;
  switch (msg.type) {
    case MessageType.GET_TAB_ID:
      return { tabId: sender.tab?.id ?? null };
    case MessageType.GET_STATUS:
      return { status: session.status };
    case MessageType.GET_FULL_STATE: {
      void resumeSession().catch(reportQueueFailure);
      const fullState = {
        sessionId: session.id,
        status: session.status,
        message: session.message,
        transcript: session.transcript,
        transcriptRevision: session.transcriptRevision,
        points: session.points,
        selectedPoints: session.selectedPoints,
        warnings: session.warnings,
        customPrompt: session.customPrompt,
        outputFormat: session.outputFormat,
        edit: session.edit,
        topicResearch: Array.from(topicResearchMap.values()),
        hasHtml: session.html !== null,
        openaiKey
      };
      return fullState;
    }
    case MessageType.GET_API_SETTINGS:
      return { openaiKey };
    case MessageType.GET_DEBUG_LOG: {
      const r = await chrome.storage.local.get(DEBUG_LOG_KEY);
      return { log: r[DEBUG_LOG_KEY] ?? [] };
    }
    case MessageType.SET_API_SETTINGS: {
      openaiKey = msg.payload.openaiKey?.trim() ?? "";
      await chrome.storage.local.set({ openaiKey });
      if (openaiKey) void recordActivation("key_saved").catch(() => {
      });
      return { ok: true };
    }
    case MessageType.PREFLIGHT:
      checkKey();
      return { ok: true };
    case MessageType.START_RECORDING_WITH_STREAM: {
      const payload = msg.payload;
      await startRecordingWithStream(payload.tabId, payload.streamId);
      return { ok: true };
    }
    case MessageType.START_RECORDING:
      return { error: "Use Start Recording from the popup." };
    case MessageType.STOP_RECORDING:
      await stopRecording();
      return { ok: true };
    case MessageType.TOPIC_SELECTED: {
      const { topic } = msg.payload;
      if (topic && session.points.includes(topic)) {
        if (!session.selectedPoints.includes(topic)) session.selectedPoints.push(topic);
        await persist();
        void startTopicResearch(topic);
      }
      return { ok: true };
    }
    case MessageType.TOPIC_DESELECTED: {
      const { topic } = msg.payload;
      session.selectedPoints = session.selectedPoints.filter((p) => p !== topic);
      await persist();
      return { ok: true };
    }
    case MessageType.SAVE_REVIEW: {
      const payload = msg.payload;
      if (payload.sessionId !== session.id) return { error: "This session has changed. Reopen Decker." };
      if (payload.selectedPoints) session.selectedPoints = payload.selectedPoints.filter((p) => session.points.includes(p));
      if (payload.customPrompt !== void 0) session.customPrompt = payload.customPrompt;
      if (payload.outputFormat) session.outputFormat = payload.outputFormat;
      if (payload.edit) session.edit = payload.edit;
      await persist();
      return { ok: true };
    }
    case MessageType.AUDIO_CHUNK:
    case MessageType.RECORDING_STOPPED: {
      const payload = msg.payload;
      if (payload.sessionId !== session.id) return { error: "Expired capture session" };
      if (!Number.isInteger(payload.sequence) || payload.sequence < 0) return { error: "Invalid audio sequence" };
      if (payload.sequence > session.lastSequence && !session.finalReceived) {
        for (let i = session.lastSequence + 1; i < payload.sequence; i++) {
          addWarning(session, `Missing audio segment ${i + 1}: audio delivery failed.`);
        }
        if (payload.base64) session.queue.push({ ...payload, attempts: 0 });
        session.lastSequence = payload.sequence;
      }
      if (msg.type === MessageType.RECORDING_STOPPED) {
        payload.missingSequences?.forEach((i) => addWarning(session, `Missing audio segment ${i + 1}: audio delivery failed.`));
        session.finalReceived = true;
      }
      await persist();
      if (session.finalReceived && !["reviewing", "done", "generating", "researching"].includes(session.status)) void finishSession();
      else if (!session.finalReceived) void processChunkQueue().catch(reportQueueFailure);
      return { ok: true };
    }
    case MessageType.CAPTURE_WARNING: {
      const payload = msg.payload;
      if (payload.sessionId === session.id) {
        addWarning(session, payload.warning);
        broadcastStatus(session.status, session.message);
        await persist();
      }
      return { ok: true };
    }
    case MessageType.GENERATE_DECK: {
      const payload = msg.payload;
      if (payload.sessionId !== session.id || session.status !== "reviewing") return { error: "Wait for the complete transcript before generating." };
      checkKey();
      session.selectedPoints = payload.selectedPoints;
      session.customPrompt = payload.customPrompt;
      session.outputFormat = payload.outputFormat ?? "doc";
      const edit = payload.transcriptEdited && payload.transcript !== void 0 ? { text: payload.transcript, baseRevision: payload.transcriptRevision ?? -1 } : void 0;
      if (edit && edit.baseRevision !== session.transcriptRevision) {
        return { error: "The transcript changed after this edit. Review the latest transcript before generating." };
      }
      session.edit = edit;
      session.status = "generating";
      await persist();
      void runPhase2(payload.selectedPoints, payload.customPrompt, edit, payload.outputFormat);
      return { ok: true };
    }
    case MessageType.RESET_STATE: {
      if (chunkProcessing || finalizing || !["idle", "reviewing", "done", "error"].includes(session.status)) return { error: "Stop capture and wait for processing before resetting." };
      session = freshSession();
      topicResearchMap.clear();
      researchInProgress.clear();
      await persist();
      return { ok: true };
    }
    case MessageType.GET_LAST_HTML:
      return { html: session.html };
    default:
      return void 0;
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if ([MessageType.OFFSCREEN_START, MessageType.OFFSCREEN_STOP, MessageType.OFFSCREEN_STATUS, MessageType.STATUS_UPDATE].includes(message.type)) return false;
  handleMessage(message, sender).then(sendResponse, (error) => sendResponse({ error: error instanceof Error ? error.message : String(error) }));
  return true;
});
void resumeSession().catch(() => {
  broadcastStatus("error", "Could not recover the saved session. Reload Decker and try again.");
});
