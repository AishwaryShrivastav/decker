import { r as reactExports, j as jsxRuntimeExports, p as providerSetup, s as statusUpdateIsCurrent, a as popupStage, b as settingsControlsDisabled, c as savedStateNotice, d as createRoot } from "../../chunks/model-BWRRjeyJ.js";
import { a as assessCaptureTab, c as captureErrorMessage } from "../../chunks/tabReadiness-lVQUvDeD.js";
import { M as MessageType } from "../../chunks/types-Do_9m9s4.js";
const C = {
  blue: "#818cf8",
  red: "#ef4444",
  green: "#34d399",
  amber: "#f59e0b",
  dimText: "#94a3b8",
  text: "#e2e8f0",
  bg: "#080c18",
  surface: "#0d1224",
  border: "rgba(255,255,255,0.08)"
};
function statusText(status, message) {
  if (message && ["processing", "finalizing", "transcribing", "extracting"].includes(status)) return message;
  switch (status) {
    case "recording":
      return "Recording meeting audio";
    case "processing":
      return "Finishing audio capture...";
    case "finalizing":
      return "Preparing saved audio...";
    case "transcribing":
      return "Finishing transcription...";
    case "extracting":
      return "Saving the transcript...";
    case "error":
      return message ?? "Recording could not start";
    default:
      return "Ready to record";
  }
}
const emptyReadiness = {
  eligible: false,
  meetingName: "Browser meeting",
  message: "Checking the active tab..."
};
function Popup() {
  const [status, setStatus] = reactExports.useState("idle");
  const [statusMessage, setStatusMessage] = reactExports.useState();
  const [warnings, setWarnings] = reactExports.useState([]);
  const [transcript, setTranscript] = reactExports.useState("");
  const [hydrated, setHydrated] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const [starting, setStarting] = reactExports.useState(false);
  const [showSettings, setShowSettings] = reactExports.useState(false);
  const [provider, setProvider] = reactExports.useState("openai");
  const [apiKey, setApiKey] = reactExports.useState("");
  const [showKey, setShowKey] = reactExports.useState(false);
  const [saveState, setSaveState] = reactExports.useState("idle");
  const [credentialSaved, setCredentialSaved] = reactExports.useState(false);
  const [readiness, setReadiness] = reactExports.useState(emptyReadiness);
  const [includeMicrophone, setIncludeMicrophone] = reactExports.useState(true);
  const [captureSource, setCaptureSource] = reactExports.useState(null);
  const [micState, setMicState] = reactExports.useState("checking");
  const sessionIdRef = reactExports.useRef("");
  const sessionGenerationRef = reactExports.useRef(-1);
  const transcriptRevisionRef = reactExports.useRef(0);
  const keyInputRef = reactExports.useRef(null);
  const setup = providerSetup(provider);
  const stage = popupStage(status, showSettings);
  const savedNotice = savedStateNotice(status);
  const displayedError = error ?? (status === "error" ? statusMessage ?? "Recording could not start." : null);
  const wordCount = transcript.trim() ? transcript.trim().split(/\s+/).length : 0;
  const settingsPending = settingsControlsDisabled(saveState);
  const refreshActiveTab = reactExports.useCallback(async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const captureTab = tab ? { id: tab.id, active: tab.active, url: tab.url, audible: tab.audible, mutedInfo: tab.mutedInfo } : void 0;
      setReadiness(assessCaptureTab(captureTab));
      return captureTab;
    } catch {
      setReadiness({
        eligible: false,
        meetingName: "Browser meeting",
        message: "Decker could not inspect the active tab. Reopen the popup and try again."
      });
      return void 0;
    }
  }, []);
  reactExports.useEffect(() => {
    const applyStatus = (payload) => {
      if (!statusUpdateIsCurrent(sessionIdRef.current, sessionGenerationRef.current, transcriptRevisionRef.current, payload)) return;
      const nextGeneration = payload.sessionGeneration ?? sessionGenerationRef.current;
      if (nextGeneration > sessionGenerationRef.current || !sessionIdRef.current && payload.sessionId) {
        if (payload.sessionId) sessionIdRef.current = payload.sessionId;
        sessionGenerationRef.current = nextGeneration;
        transcriptRevisionRef.current = 0;
        setTranscript("");
        setWarnings([]);
      }
      if (payload.transcriptRevision !== void 0) transcriptRevisionRef.current = payload.transcriptRevision;
      if (payload.captureSource !== void 0) setCaptureSource(payload.captureSource);
      if (payload.includeMicrophone !== void 0) setIncludeMicrophone(payload.includeMicrophone);
      setStatus(payload.status);
      setStatusMessage(payload.message);
      if (payload.warnings) setWarnings(payload.warnings);
      if (payload.transcript !== void 0) setTranscript(payload.transcript);
    };
    const onMessage = (message) => {
      if (message.type === MessageType.STATUS_UPDATE) applyStatus(message.payload);
    };
    chrome.runtime.onMessage.addListener(onMessage);
    chrome.runtime.sendMessage({ type: MessageType.GET_FULL_STATE }).then((response) => {
      if (!response || response.error) throw new Error(response?.error ?? "Decker could not restore the saved recording.");
      applyStatus(response);
      setProvider(response.provider);
      setApiKey(response.apiKey);
      setCredentialSaved(Boolean(response.apiKey.trim()));
      setShowSettings(!response.apiKey.trim());
      setHydrated(true);
    }).catch((reason) => setError(reason instanceof Error ? reason.message : String(reason)));
    return () => chrome.runtime.onMessage.removeListener(onMessage);
  }, []);
  reactExports.useEffect(() => {
    if (stage === "setup") keyInputRef.current?.focus();
  }, [stage, provider]);
  reactExports.useEffect(() => {
    void refreshActiveTab();
    const refresh = () => {
      void refreshActiveTab();
    };
    chrome.tabs.onActivated?.addListener(refresh);
    chrome.tabs.onUpdated?.addListener(refresh);
    return () => {
      chrome.tabs.onActivated?.removeListener(refresh);
      chrome.tabs.onUpdated?.removeListener(refresh);
    };
  }, [refreshActiveTab]);
  reactExports.useEffect(() => {
    let permission;
    let mounted = true;
    navigator.permissions.query({ name: "microphone" }).then((result) => {
      if (!mounted) return;
      permission = result;
      const update = () => setMicState(result.state === "granted" ? "granted" : result.state === "denied" ? "denied" : "prompt");
      update();
      result.onchange = update;
    }).catch(() => {
      if (mounted) setMicState("unavailable");
    });
    return () => {
      mounted = false;
      if (permission) permission.onchange = null;
    };
  }, []);
  const buttonStyle = reactExports.useMemo(() => ({
    width: "100%",
    padding: "10px 14px",
    border: "none",
    borderRadius: 8,
    fontSize: 13,
    fontWeight: 700,
    cursor: "pointer"
  }), []);
  const openMicPermission = () => chrome.tabs.create({ url: chrome.runtime.getURL("permission.html") });
  const handleProviderChange = (next) => {
    if (settingsPending || next === provider) return;
    setProvider(next);
    setApiKey("");
    setCredentialSaved(false);
    setSaveState("idle");
    setError(null);
  };
  const handleSaveKey = async () => {
    if (settingsPending) return;
    setError(null);
    setSaveState("validating");
    try {
      const response = await chrome.runtime.sendMessage({
        type: MessageType.SET_API_SETTINGS,
        payload: { provider, apiKey: apiKey.trim() }
      });
      if (!response?.ok) throw new Error(response?.error ?? `${setup.label} could not validate this key.`);
      setCredentialSaved(true);
      setSaveState("saved");
    } catch (reason) {
      setCredentialSaved(false);
      setSaveState("idle");
      setError(reason instanceof Error ? reason.message : String(reason));
    }
  };
  const handleClearKey = async () => {
    if (settingsPending) return;
    setError(null);
    setSaveState("clearing");
    try {
      const response = await chrome.runtime.sendMessage({ type: MessageType.CLEAR_PROVIDER_SETTINGS });
      if (!response?.ok) throw new Error(response?.error ?? "Decker could not clear the saved key.");
      setApiKey("");
      setCredentialSaved(false);
      setSaveState("idle");
    } catch (reason) {
      setSaveState("idle");
      setError(reason instanceof Error ? reason.message : String(reason));
    }
  };
  const handleStart = async () => {
    setError(null);
    setStarting(true);
    try {
      const preflight = await chrome.runtime.sendMessage({ type: MessageType.PREFLIGHT });
      if (!preflight?.ok) throw new Error(preflight?.error ?? `Save a ${setup.label} API key before recording.`);
      const tab = await refreshActiveTab();
      const currentReadiness = assessCaptureTab(tab);
      if (!currentReadiness.eligible || !tab?.id) throw new Error(currentReadiness.message);
      if (includeMicrophone) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          stream.getTracks().forEach((track) => track.stop());
          setMicState("granted");
        } catch {
          setMicState("denied");
          throw new Error("Microphone access was denied. Turn off Include microphone to record tab audio only, or allow microphone access first.");
        }
      }
      const streamId = await new Promise((resolve, reject) => {
        chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id }, (id) => {
          if (chrome.runtime.lastError) reject(new Error(captureErrorMessage(chrome.runtime.lastError.message ?? "Capture permission was denied.")));
          else if (!id) reject(new Error("Decker could not start tab audio capture. Reopen the meeting tab and try again."));
          else resolve(id);
        });
      });
      const started = await chrome.runtime.sendMessage({
        type: MessageType.START_RECORDING_WITH_STREAM,
        payload: { tabId: tab.id, streamId, includeMicrophone }
      });
      if (!started?.ok) throw new Error(captureErrorMessage(started?.error ?? "Audio capture did not start."));
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
    } finally {
      setStarting(false);
    }
  };
  const handleStop = async () => {
    setError(null);
    const response = await chrome.runtime.sendMessage({ type: MessageType.STOP_RECORDING }).catch(() => null);
    if (!response?.ok) setError(response?.error ?? "Decker could not stop the recorder. Reopen the popup to recover the session.");
  };
  const micLabel = !includeMicrophone ? "Microphone excluded" : micState === "granted" ? "Microphone ready" : micState === "denied" ? "Microphone blocked" : micState === "checking" ? "Checking microphone" : "Microphone permission needed";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { style: { padding: "14px 16px", minWidth: 340, maxWidth: 420, background: C.bg, color: C.text, minHeight: "100%" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "flex", alignItems: "center", gap: 10 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: chrome.runtime.getURL("icons/icon48.png"), width: 28, height: 28, style: { borderRadius: 6 }, alt: "" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { fontSize: 17, fontWeight: 800, color: C.blue }, children: "Decker" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShowSettings((value) => !value), "aria-label": "Settings", style: { background: "none", border: "none", color: C.dimText, cursor: "pointer", fontSize: 14 }, children: "Settings" })
    ] }),
    stage === "setup" && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { style: { marginBottom: 12, padding: 12, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { role: "group", "aria-label": "AI provider", style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 12 }, children: ["openai", "gemini"].map((option) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", "aria-pressed": provider === option, disabled: settingsPending, onClick: () => handleProviderChange(option), style: { ...buttonStyle, padding: "8px", color: provider === option ? C.bg : C.text, background: provider === option ? C.blue : C.bg, border: `1px solid ${provider === option ? C.blue : C.border}` }, children: providerSetup(option).label }, option)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "provider-key", style: { display: "block", fontSize: 12, marginBottom: 5 }, children: setup.keyLabel }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "flex", gap: 6 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            ref: keyInputRef,
            id: "provider-key",
            type: showKey ? "text" : "password",
            value: apiKey,
            placeholder: setup.placeholder,
            disabled: settingsPending,
            onChange: (event) => {
              setApiKey(event.target.value);
              setCredentialSaved(false);
              setSaveState("idle");
            },
            style: { flex: 1, minWidth: 0, padding: 8, borderRadius: 6, border: `1px solid ${C.border}`, background: C.bg, color: C.text }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", disabled: settingsPending, onClick: () => setShowKey((value) => !value), style: { padding: "0 10px", borderRadius: 6, border: `1px solid ${C.border}`, background: C.bg, color: C.dimText, cursor: "pointer" }, children: showKey ? "Hide" : "Show" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: setup.helpUrl, target: "_blank", rel: "noopener noreferrer", style: { display: "inline-block", marginTop: 7, color: C.blue, fontSize: 11 }, children: setup.helpText }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { style: { color: C.dimText, fontSize: 11, lineHeight: 1.5, margin: "9px 0" }, children: [
        "Decker saves this key in extension storage. Requests go directly to ",
        setup.label,
        "; the developer does not receive your key or meeting content."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "flex", gap: 7 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: !apiKey.trim() || settingsPending,
            onClick: handleSaveKey,
            style: { ...buttonStyle, flex: 1, padding: "8px", color: C.bg, background: C.blue, opacity: apiKey.trim() ? 1 : 0.5 },
            children: saveState === "validating" ? "Checking key..." : saveState === "saved" ? "Key saved" : "Save key"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", disabled: settingsPending, onClick: handleClearKey, style: { ...buttonStyle, width: "auto", padding: "8px 12px", color: C.text, background: "transparent", border: `1px solid ${C.border}` }, children: saveState === "clearing" ? "Clearing..." : "Clear key" })
      ] })
    ] }),
    displayedError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { role: "alert", style: { marginBottom: 10, padding: 9, borderRadius: 6, color: C.red, background: "rgba(239,68,68,0.1)", fontSize: 11, lineHeight: 1.45 }, children: displayedError }),
    warnings.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { role: "alert", style: { marginBottom: 10, padding: 9, borderRadius: 6, color: C.amber, background: C.surface, fontSize: 11 }, children: warnings.map((warning) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: warning }, warning)) }),
    stage === "readiness" && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { style: { fontSize: 15, margin: "0 0 10px" }, children: "Ready to record" }),
      savedNotice && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { role: "status", style: { marginBottom: 9, padding: 9, borderRadius: 6, color: C.green, background: C.surface, fontSize: 11 }, children: savedNotice }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { padding: 11, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, display: "grid", gap: 8, fontSize: 12 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { color: credentialSaved ? C.green : C.amber }, children: credentialSaved ? `${setup.label} key saved` : `Save a ${setup.label} API key` }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { color: readiness.eligible ? C.green : C.amber }, children: readiness.message }),
        readiness.warning && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { color: C.amber }, children: readiness.warning }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { color: includeMicrophone && micState !== "granted" ? C.amber : C.green }, children: micLabel })
      ] }),
      !credentialSaved && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShowSettings(true), style: { ...buttonStyle, marginTop: 9, color: C.text, background: "transparent", border: `1px solid ${C.border}` }, children: "Set up provider" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: { display: "flex", alignItems: "center", gap: 8, marginTop: 11, fontSize: 12, color: C.text }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: includeMicrophone, onChange: (event) => setIncludeMicrophone(event.target.checked) }),
        "Include my microphone"
      ] }),
      includeMicrophone && micState !== "granted" && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: openMicPermission, style: { ...buttonStyle, marginTop: 8, color: C.text, background: "transparent", border: `1px solid ${C.border}` }, children: "Allow microphone access" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { margin: "11px 0", color: C.dimText, fontSize: 11, lineHeight: 1.55 }, children: "Decker records eligible browser tabs and checks the captured audio signal after starting. Native Zoom, Teams, and Webex apps are not supported." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { style: { margin: "0 0 11px", color: C.dimText, fontSize: 11, lineHeight: 1.55 }, children: [
        "By starting, you confirm that you have permission to record. Audio and transcript content go directly to ",
        setup.label,
        " using your key. Provider API charges may apply. One recovery session is stored on this device. ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://decker.techforgood.studio/privacy", target: "_blank", rel: "noopener noreferrer", style: { color: C.blue }, children: "Privacy policy" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handleStart,
          disabled: starting || !hydrated || !credentialSaved || !readiness.eligible,
          style: { ...buttonStyle, color: C.bg, background: C.blue, opacity: hydrated && credentialSaved && readiness.eligible ? 1 : 0.5 },
          children: starting ? "Starting recording..." : "Start recording"
        }
      )
    ] }),
    stage === "recording" && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { style: { padding: 13, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "flex", alignItems: "center", gap: 8, color: status === "recording" ? C.red : C.amber, fontSize: 13, fontWeight: 700 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { width: 8, height: 8, borderRadius: "50%", background: status === "recording" ? C.red : C.amber } }),
        statusText(status, statusMessage)
      ] }),
      status === "recording" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { marginTop: 9, color: C.dimText, fontSize: 11 }, children: [
          captureSource?.name ?? readiness.meetingName,
          ", ",
          includeMicrophone ? "tab audio and microphone" : "tab audio only"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { marginTop: 5, color: C.dimText, fontSize: 11 }, children: wordCount ? `${wordCount} words transcribed so far` : "Listening for speech..." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: handleStop, style: { ...buttonStyle, marginTop: 12, color: "#fff", background: C.red }, children: "Stop recording" })
      ] }),
      status !== "recording" && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { margin: "9px 0 0", color: C.dimText, fontSize: 11 }, children: "Keep Decker open while the last audio segments are saved." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("style", { children: `* { box-sizing: border-box; } body { margin: 0; background: ${C.bg}; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; } button:disabled { cursor: not-allowed; }` })
  ] });
}
const container = document.getElementById("popup-root");
const root = createRoot(container);
root.render(reactExports.createElement(Popup));
