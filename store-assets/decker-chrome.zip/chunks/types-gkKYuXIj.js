var MessageType = /* @__PURE__ */ ((MessageType2) => {
  MessageType2["SAVE_REVIEW"] = "SAVE_REVIEW";
  MessageType2["PREFLIGHT"] = "PREFLIGHT";
  MessageType2["OFFSCREEN_STATUS"] = "OFFSCREEN_STATUS";
  MessageType2["CAPTURE_WARNING"] = "CAPTURE_WARNING";
  MessageType2["GET_LAST_HTML"] = "GET_LAST_HTML";
  MessageType2["GET_TAB_ID"] = "GET_TAB_ID";
  MessageType2["START_RECORDING"] = "START_RECORDING";
  MessageType2["STOP_RECORDING"] = "STOP_RECORDING";
  MessageType2["GET_STATUS"] = "GET_STATUS";
  MessageType2["GET_API_SETTINGS"] = "GET_API_SETTINGS";
  MessageType2["SET_API_SETTINGS"] = "SET_API_SETTINGS";
  MessageType2["GET_DEBUG_LOG"] = "GET_DEBUG_LOG";
  MessageType2["GENERATE_DECK"] = "GENERATE_DECK";
  MessageType2["START_RECORDING_WITH_STREAM"] = "START_RECORDING_WITH_STREAM";
  MessageType2["TOPIC_SELECTED"] = "TOPIC_SELECTED";
  MessageType2["TOPIC_DESELECTED"] = "TOPIC_DESELECTED";
  MessageType2["GET_FULL_STATE"] = "GET_FULL_STATE";
  MessageType2["RESET_STATE"] = "RESET_STATE";
  MessageType2["OFFSCREEN_START"] = "OFFSCREEN_START";
  MessageType2["OFFSCREEN_STOP"] = "OFFSCREEN_STOP";
  MessageType2["AUDIO_CHUNK"] = "AUDIO_CHUNK";
  MessageType2["RECORDING_STOPPED"] = "RECORDING_STOPPED";
  MessageType2["STATUS_UPDATE"] = "STATUS_UPDATE";
  return MessageType2;
})(MessageType || {});
export {
  MessageType as M
};
