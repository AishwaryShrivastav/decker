const ACTIVATION_STORAGE_KEY = "deckerActivationV1";
const ACTIVATION_MILESTONES = [
  "key_saved",
  "recording_started",
  "transcript_ready",
  "output_generated"
];
function freshState(at) {
  return { version: 1, firstSeenAt: at, milestones: {} };
}
async function getActivationState(storage = chrome.storage.local) {
  const result = await storage.get(ACTIVATION_STORAGE_KEY);
  const value = result[ACTIVATION_STORAGE_KEY];
  if (!value || typeof value !== "object") return null;
  const state = value;
  if (state.version !== 1 || !state.milestones || typeof state.milestones !== "object") return null;
  return state;
}
async function recordActivation(milestone, storage = chrome.storage.local, now = () => /* @__PURE__ */ new Date()) {
  const timestamp = now().toISOString();
  const existing = await getActivationState(storage);
  const state = existing ?? freshState(timestamp);
  if (!state.milestones[milestone]) {
    state.milestones[milestone] = timestamp;
    await storage.set({ [ACTIVATION_STORAGE_KEY]: state });
  }
  return state;
}
function completedMilestones(state) {
  if (!state) return [];
  return ACTIVATION_MILESTONES.filter((milestone) => Boolean(state.milestones[milestone]));
}
export {
  completedMilestones as c,
  getActivationState as g,
  recordActivation as r
};
