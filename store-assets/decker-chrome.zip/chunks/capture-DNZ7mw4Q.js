function freshSession(id = crypto.randomUUID()) {
  return {
    id,
    status: "idle",
    tabId: null,
    transcript: "",
    transcriptRevision: 0,
    points: [],
    selectedPoints: [],
    customPrompt: "",
    outputFormat: "doc",
    research: [],
    warnings: [],
    queue: [],
    lastSequence: -1,
    finalReceived: false,
    html: null
  };
}
function recoverSession(saved) {
  const state = structuredClone(saved);
  state.research = state.research.map((r) => r.status === "researching" ? { ...r, status: "error" } : r);
  if (["generating", "researching"].includes(state.status)) {
    state.status = "reviewing";
    state.message = "Generation was interrupted. Your transcript and instructions were recovered. Generate again when ready.";
  }
  return state;
}
function transcriptForGeneration(state, edit = state.edit) {
  return edit?.baseRevision === state.transcriptRevision ? edit.text : state.transcript;
}
function reconcileTopics(state, points) {
  state.selectedPoints = points.filter((p) => state.selectedPoints.includes(p) || !state.points.includes(p));
  state.points = points;
}
function addWarning(state, warning) {
  if (!state.warnings.includes(warning)) state.warnings.push(warning);
}
const waitForRetry = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const MAX_TRANSCRIPTION_ATTEMPTS = 3;
async function processPendingChunks(state, transcribe, save, sleep = waitForRetry, onProgress = () => {
}) {
  while (state.queue.length) {
    const chunk = state.queue[0];
    let text;
    while (chunk.attempts < MAX_TRANSCRIPTION_ATTEMPTS) {
      chunk.attempts++;
      await save();
      try {
        text = await transcribe(chunk);
        if (!text.trim()) throw new Error("Empty transcription");
        break;
      } catch {
        if (chunk.attempts < MAX_TRANSCRIPTION_ATTEMPTS) await sleep(1e3 * 2 ** (chunk.attempts - 1));
      }
    }
    if (text === void 0 || !text.trim()) {
      text = `[Missing audio segment ${chunk.sequence + 1}: transcription failed after ${MAX_TRANSCRIPTION_ATTEMPTS} attempts.]`;
      addWarning(state, text);
    }
    state.transcript = [state.transcript, text].filter(Boolean).join(" ");
    state.transcriptRevision++;
    state.queue.shift();
    await save();
    onProgress();
  }
}
function addCaptureNotice(html, warnings) {
  if (!warnings.length) return html;
  const escape = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const notice = `<aside role="note" style="position:relative;z-index:2147483647;padding:16px;background:#fff3cd;color:#533f03;font:14px/1.5 sans-serif"><strong>Capture warnings</strong><ul>${warnings.map((w) => `<li>${escape(w)}</li>`).join("")}</ul></aside>`;
  return /<body\b[^>]*>/i.test(html) ? html.replace(/<body\b[^>]*>/i, (body) => body + notice) : notice + html;
}
export {
  addWarning as a,
  addCaptureNotice as b,
  reconcileTopics as c,
  freshSession as f,
  processPendingChunks as p,
  recoverSession as r,
  transcriptForGeneration as t,
  waitForRetry as w
};
